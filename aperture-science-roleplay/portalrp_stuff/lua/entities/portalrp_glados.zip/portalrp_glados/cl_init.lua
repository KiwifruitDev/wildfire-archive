// ============================================================================================ //
/* 
 * Wildfire Servers - Portal RP - Base Addon
*  File description: GLaDoS clientside script file
 * Copyright (c) 2021 Wildfire Servers
*  Any unauthorized reproduction, distribution, or modification of this material is prohibited.
 */
// ============================================================================================ //
// BASE FILE HEADER DO NOT MODIFY!! //
local ent = FindMetaTable("Entity") //
local ply = FindMetaTable("Player") //
local vec = FindMetaTable("Vector") //
// ================================ //

include("shared.lua")


function ENT:Draw()

    self:DrawModel()

end

